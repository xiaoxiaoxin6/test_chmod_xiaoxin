# test_chmod_xiaoxin
test the right for python files.


